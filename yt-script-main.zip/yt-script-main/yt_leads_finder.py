import requests
import pandas as pd
from datetime import datetime, timedelta
import math
import time
from dotenv import load_dotenv
import os

load_dotenv()

# =============================
# CONFIG
# =============================

API_KEY = os.getenv("API_KEY")
BASE_URL = "https://www.googleapis.com/youtube/v3"

REGION = "US"  # Single region (efficient)
RELEVANCE_LANGUAGE = "en"

MAX_SEARCH_PAGES = 3       # 3 pages = 150 results max
MAX_CHANNELS_EVALUATED = 150  # Safety cap


# =============================
# INPUT SECTION
# =============================

print("\n🎯 YouTube Lead Finder (Efficient + High Quality)\n")

KEYWORD = input("Keyword to search: ").strip()
MIN_SUBS = int(input("Minimum subscribers: ").strip())
MAX_SUBS = int(input("Maximum subscribers: ").strip())

MIN_UPLOADS_30D = int(input("Minimum uploads in last 30 days: ").strip())

min_avg_views_input = input("Minimum average views (optional, press Enter to skip): ").strip()
MIN_AVG_VIEWS = int(min_avg_views_input) if min_avg_views_input else 0


# =============================
# SEARCH CHANNELS (PAGINATED)
# =============================

def search_channels(keyword):
    all_channels = set()
    next_page_token = None

    for page in range(MAX_SEARCH_PAGES):
        print(f"🔍 Fetching search page {page + 1}")

        params = {
            "part": "snippet",
            "q": keyword,
            "type": "video",
            "order": "date",
            "maxResults": 50,
            "relevanceLanguage": RELEVANCE_LANGUAGE,
            "regionCode": REGION,
            "key": API_KEY
        }

        if next_page_token:
            params["pageToken"] = next_page_token

        res = requests.get(f"{BASE_URL}/search", params=params).json()

        for item in res.get("items", []):
            all_channels.add(item["snippet"]["channelId"])

        next_page_token = res.get("nextPageToken")
        if not next_page_token:
            break

        time.sleep(0.2)

    return list(all_channels)


# =============================
# API HELPERS
# =============================

def get_channel_details_batch(channel_ids):
    """
    Batch fetch channel details (max 50 per call).
    Much more efficient than one-by-one.
    """
    channels_data = []

    for i in range(0, len(channel_ids), 50):
        batch = channel_ids[i:i+50]

        params = {
            "part": "statistics,contentDetails,snippet",
            "id": ",".join(batch),
            "key": API_KEY
        }

        res = requests.get(f"{BASE_URL}/channels", params=params).json()
        channels_data.extend(res.get("items", []))

        time.sleep(0.2)

    return channels_data


def get_recent_videos(playlist_id):
    params = {
        "part": "snippet",
        "playlistId": playlist_id,
        "maxResults": 50,
        "key": API_KEY
    }

    res = requests.get(f"{BASE_URL}/playlistItems", params=params).json()
    return res.get("items", [])


def get_video_stats(video_ids):
    if not video_ids:
        return []

    params = {
        "part": "statistics",
        "id": ",".join(video_ids),
        "key": API_KEY
    }

    res = requests.get(f"{BASE_URL}/videos", params=params).json()
    return res.get("items", [])


# =============================
# MAIN LOGIC
# =============================

def run():
    channels = search_channels(KEYWORD)
    print(f"\n🔎 Found {len(channels)} unique channels\n")

    channels = channels[:MAX_CHANNELS_EVALUATED]

    # Batch fetch channel metadata
    channels_data = get_channel_details_batch(channels)

    leads = []

    for channel in channels_data:
        try:
            subs = int(channel["statistics"].get("subscriberCount", 0))

            # Early filter before expensive calls
            if subs < MIN_SUBS or subs > MAX_SUBS:
                continue

            uploads_playlist = channel["contentDetails"]["relatedPlaylists"]["uploads"]
            videos = get_recent_videos(uploads_playlist)

            cutoff = datetime.utcnow() - timedelta(days=30)
            recent_count = 0
            video_ids = []
            last_upload_date = None

            for vid in videos:
                published = datetime.strptime(
                    vid["snippet"]["publishedAt"],
                    "%Y-%m-%dT%H:%M:%SZ"
                )

                if not last_upload_date:
                    last_upload_date = published

                if published > cutoff:
                    recent_count += 1

                video_ids.append(vid["snippet"]["resourceId"]["videoId"])

            if recent_count < MIN_UPLOADS_30D:
                continue

            stats = get_video_stats(video_ids[:10])
            views = [int(v["statistics"].get("viewCount", 0)) for v in stats]
            avg_views = sum(views) / len(views) if views else 0

            if avg_views < MIN_AVG_VIEWS:
                continue

            # Improved scoring
            score = (
                recent_count * 3 +
                math.log10(subs) * 2 +
                (avg_views / 10000)
            )

            leads.append({
                "Channel Name": channel["snippet"]["title"],
                "Channel URL": f"https://youtube.com/channel/{channel['id']}",
                "Subscribers": subs,
                "Uploads Last 30d": recent_count,
                "Avg Views (Last 10)": int(avg_views),
                "Last Upload": last_upload_date.strftime("%Y-%m-%d") if last_upload_date else "",
                "Score": round(score, 2)
            })

            print(f"✔ Qualified: {channel['snippet']['title']}")

        except Exception as e:
            print("⚠ Error:", e)

    df = pd.DataFrame(leads)

    if df.empty:
        print("\n❌ No leads matched your filters.")
        return

    df = df.sort_values(by="Score", ascending=False)

    filename = f"yt_leads_{KEYWORD.replace(' ', '_')}.csv"
    df.to_csv(filename, index=False)

    print(f"\n✅ Done! {len(df)} leads saved to {filename}")


if __name__ == "__main__":
    run()